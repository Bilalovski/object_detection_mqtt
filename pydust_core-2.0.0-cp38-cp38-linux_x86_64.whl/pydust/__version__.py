"""The dust-core version definition."""

VERSION = "2.0.0"
